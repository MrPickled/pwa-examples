window.onload = function myload(){
    // alert(1)
    // document.querySelector('.add-button').click()
    setInterval(() => {
        document.querySelector('.add-button').click()
      }, 1)
    // alert(3)
    // btn2.click()
    // //  document.getElementById('btn2').click()
}